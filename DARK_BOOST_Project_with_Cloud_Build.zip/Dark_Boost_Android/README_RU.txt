DARK BOOST — Android Studio project

Что умеет эта первая сборка:
- Проверяет, запущен ли Shizuku, и запрашивает разрешение.
- Находит глобальную Free Fire (com.dts.freefireth) и Free Fire MAX (com.dts.freefiremax).
- Открывает выбранную установленную игру кнопкой «Играть».
- По нажатию просит Android GameManager включить performance или standard mode для игры.
- Показывает ответ Android в журнале.

Чего не делает:
- Не гарантирует устранение всех лагов или рост FPS.
- Не разгоняет CPU/GPU и не меняет частоты.
- Не закрывает принудительно системные процессы.
- Не меняет файлы игры, конфиги, DPI, сенсор, античит или сетевые параметры.
- Не обходит ограничения Android/Free Fire.

СБОРКА APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив и открой папку Dark_Boost_Android как проект.
3. Дождись Gradle Sync. Нужны JDK 17 и Android SDK Platform 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK появится в app/build/outputs/apk/debug/.

НАСТРОЙКА НА ТЕЛЕФОНЕ:
1. Установи DARK BOOST и Shizuku.
2. В Shizuku запусти службу. На Android 11+ это можно сделать через Wireless debugging; на не-root устройстве Shizuku может требовать повторного запуска после перезагрузки.
3. Открой DARK BOOST, нажми «Проверить / разрешить Shizuku» и выдай доступ.
4. Нажми «Включить режим производительности». Если Android сообщает, что режим не поддерживается, это ограничение устройства/игры — приложение не форсирует его скрытыми настройками.
5. Нажми «Играть» у установленной версии Free Fire.

ПРИМЕЧАНИЕ О SHIZUKU:
Используется Shizuku API 13.1.5 и команда Android GameManager `cmd game mode`.
Команда `performance` доступна не на каждом Android-устройстве и не для каждой игры. На некоторых прошивках Xiaomi команда может вернуть, что режим не поддерживается. Кнопка обычного режима возвращает standard mode.

Проверенные справки:
- Shizuku API: https://github.com/RikkaApps/Shizuku-API
- Android Game Mode: https://developer.android.com/games/optimize/adpf/gamemode/gamemode-api
