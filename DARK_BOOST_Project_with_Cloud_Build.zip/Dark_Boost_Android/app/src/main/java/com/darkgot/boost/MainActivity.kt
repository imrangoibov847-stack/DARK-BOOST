package com.darkgot.boost

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val purple = Color.rgb(164, 119, 255)
    private val bg = Color.rgb(9, 7, 15)
    private val panel = Color.rgb(24, 17, 37)
    private val muted = Color.rgb(185, 171, 207)
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var connectButton: Button
    private val requestCode = 4107

    private val gamePackages = listOf(
        "com.dts.freefireth" to "Free Fire",
        "com.dts.freefiremax" to "Free Fire MAX"
    )

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == requestCode) {
            runOnUiThread {
                updateShizukuStatus()
                if (result == PackageManager.PERMISSION_GRANTED) {
                    showLog("Доступ Shizuku разрешён. Теперь можно применить игровой режим.")
                } else {
                    showLog("Доступ Shizuku не выдан. Разреши его в Shizuku и попробуй снова.")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addRequestPermissionResultListener(permissionListener)
        updateShizukuStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        executor.shutdown()
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        val logo = TextView(this).apply {
            text = "DB"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(purple, 18)
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        root.addView(label("DARK BOOST", 27f, Color.WHITE, true).apply {
            letterSpacing = .12f
            setPadding(0, dp(15), 0, 0)
        })
        root.addView(label("FREE FIRE PERFORMANCE TOOL", 11f, purple, true))
        root.addView(label("Подготовка телефона к игре без читов и изменения файлов игры.", 14f, muted, false).apply {
            setPadding(0, dp(8), 0, dp(20))
        })

        root.addView(cardTitle("SHIZUKU CONNECTION"))
        status = label("Проверка подключения…", 14f, muted, true)
        root.addView(status)
        connectButton = button("ПРОВЕРИТЬ / РАЗРЕШИТЬ SHIZUKU") { requestShizuku() }
        root.addView(connectButton, matchWrap())

        root.addView(cardTitle("ВЫБОР ИГРЫ"))
        gamePackages.forEach { (pkg, name) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel, 15)
                setPadding(dp(14), dp(10), dp(10), dp(10))
            }
            val info = TextView(this).apply {
                text = "$name\n${if (isInstalled(pkg)) "Установлена" else "Не найдена"}"
                setTextColor(Color.WHITE)
                textSize = 14f
                setLineSpacing(dp(3).toFloat(), 1f)
            }
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val launch = button("ИГРАТЬ") { launchGame(pkg, name) }
            launch.isEnabled = isInstalled(pkg)
            row.addView(launch)
            root.addView(row, matchWrap().apply { bottomMargin = dp(9) })
        }

        root.addView(cardTitle("ОПТИМИЗАЦИЯ"))
        root.addView(label("Игровой режим Android", 15f, Color.WHITE, true))
        root.addView(label("Попросить Android включить режим производительности для выбранной игры. Сработает только если устройство и сама игра поддерживают эту функцию.", 12f, muted, false).apply {
            setPadding(0, dp(5), 0, dp(10))
        })
        root.addView(button("ВКЛЮЧИТЬ РЕЖИМ ПРОИЗВОДИТЕЛЬНОСТИ") {
            applyGameMode("performance")
        }, matchWrap())
        root.addView(button("ВЕРНУТЬ ОБЫЧНЫЙ РЕЖИМ") {
            applyGameMode("standard")
        }, matchWrap().apply { topMargin = dp(8) })

        root.addView(cardTitle("ЖУРНАЛ"))
        log = label("Ожидание действий…", 12f, muted, false)
        log.setPadding(dp(12), dp(12), dp(12), dp(12))
        log.background = rounded(panel, 12)
        root.addView(log, matchWrap())

        root.addView(label("Важно: приложение не разгоняет процессор сверх нормы, не меняет файлы Free Fire, не отключает системную защиту и не обещает убрать все лаги. Следи за нагревом телефона.", 11f, muted, false).apply {
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            showLog("Shizuku не запущен. Открой приложение Shizuku и запусти службу через Wireless debugging.")
            try {
                startActivity(packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api"))
            } catch (_: Exception) {}
            updateShizukuStatus()
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            updateShizukuStatus()
            showLog("Shizuku подключён и разрешение уже выдано.")
        } else {
            Shizuku.requestPermission(requestCode)
        }
    }

    private fun updateShizukuStatus() {
        val connected = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        val granted = connected && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        status.text = when {
            granted -> "● Подключён · разрешение выдано"
            connected -> "● Служба запущена · нужно разрешение"
            else -> "● Не подключён · запусти Shizuku"
        }
        status.setTextColor(if (granted) Color.rgb(110, 220, 150) else Color.rgb(255, 190, 105))
    }

    private fun applyGameMode(mode: String) {
        val pkg = gamePackages.firstOrNull { isInstalled(it.first) }?.first
        if (pkg == null) {
            showLog("Не найдена Free Fire или Free Fire MAX. Установи игру из официального источника.")
            return
        }
        if (!Shizuku.pingBinder()) {
            showLog("Сначала запусти Shizuku.")
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            requestShizuku()
            showLog("Нужно выдать приложению разрешение Shizuku.")
            return
        }
        executor.execute {
            try {
                // Only asks Android GameManager for its documented per-game mode.
                // It does not alter game data or force unsupported device_config overrides.
                val process = Shizuku.newProcess(
                    arrayOf("sh", "-c", "cmd game mode $mode $pkg"),
                    null,
                    null
                )
                val output = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val error = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val code = process.waitFor()
                runOnUiThread {
                    val result = (output + "\n" + error).trim()
                    showLog(if (code == 0) {
                        if (result.isBlank()) "Команда отправлена Android: $mode для $pkg. Проверь результат в игре."
                        else "Ответ Android:\n$result"
                    } else {
                        "Android не применил режим (код $code).\n${result.ifBlank { "Возможно, эта игра или прошивка не поддерживает Game Mode." }}"
                    })
                }
            } catch (e: Exception) {
                runOnUiThread { showLog("Ошибка Shizuku: ${e.message ?: "не удалось выполнить команду"}") }
            }
        }
    }

    private fun launchGame(pkg: String, name: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            showLog("$name не установлена.")
            return
        }
        startActivity(intent)
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Exception) { false }

    private fun showLog(message: String) {
        log.text = message
    }

    private fun cardTitle(text: String): TextView = label(text, 11f, purple, true).apply {
        setPadding(0, dp(23), 0, dp(10))
        letterSpacing = .1f
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 11f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(104, 59, 183), 13)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
